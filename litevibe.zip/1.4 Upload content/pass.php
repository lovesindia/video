<?php require_once("load.php");
user::LoginUser(2);