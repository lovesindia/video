<?php //Version
$phpVersion = 1;
$phpSubversion = '4';
?>